	<footer class="entry-footer">
		<?php affinity_entry_footer(); ?>
	</footer><!-- .entry-footer -->

		<div class="entry-meta">
			<?php affinity_posted_on(); ?>
		</div><!-- .entry-meta -->
